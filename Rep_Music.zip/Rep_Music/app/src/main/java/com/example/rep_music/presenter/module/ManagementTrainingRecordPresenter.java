package com.example.rep_music.presenter.module;

public class ManagementTrainingRecordPresenter {
}
