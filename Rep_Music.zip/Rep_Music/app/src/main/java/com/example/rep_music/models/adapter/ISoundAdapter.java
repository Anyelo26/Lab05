package com.example.rep_music.models.adapter;

public interface ISoundAdapter {
}
