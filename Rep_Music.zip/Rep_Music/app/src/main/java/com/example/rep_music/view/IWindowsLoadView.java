package com.example.rep_music.view;

public interface IWindowsLoadView {
}
