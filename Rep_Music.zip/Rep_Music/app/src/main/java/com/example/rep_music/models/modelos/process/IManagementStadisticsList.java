package com.example.rep_music.models.modelos.process;

public interface IManagementStadisticsList {
}
