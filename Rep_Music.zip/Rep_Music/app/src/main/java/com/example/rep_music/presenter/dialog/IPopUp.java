package com.example.rep_music.presenter.dialog;

public interface IPopUp {
}
