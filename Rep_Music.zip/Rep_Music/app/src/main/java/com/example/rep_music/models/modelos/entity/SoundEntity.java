package com.example.rep_music.models.modelos.entity;

import java.io.Serializable;
public class SoundEntity implements Serializable{
    private int id;
    private String titulo;
    private String path;

    public SoundEntity(){};
    public SoundEntity(int id, String titulo, String path) {
        this.id = id;
        this.titulo = titulo;
        this.path = path;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
