package com.example.rep_music.models.modelos.process;

public class Training {
    private String id;
    private String idPerson;
    private double numCalorias;//cal/kcal
    private double recorrido;//en km
    private int numPasos;
    private int tiempoTranscurrido;//en segundos

    public Training(){};
    public Training(String id, String idPerson, double numCalorias, double recorrido, int numPasos, int tiempoTranscurrido) {
        this.id = id;
        this.idPerson = idPerson;
        this.numCalorias = numCalorias;
        this.recorrido = recorrido;
        this.numPasos = numPasos;
        this.tiempoTranscurrido = tiempoTranscurrido;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdPerson() {
        return idPerson;
    }

    public void setIdPerson(String idPerson) {
        this.idPerson = idPerson;
    }

    public double getNumCalorias() {
        return numCalorias;
    }

    public void setNumCalorias(double numCalorias) {
        this.numCalorias = numCalorias;
    }

    public double getRecorrido() {
        return recorrido;
    }

    public void setRecorrido(double recorrido) {
        this.recorrido = recorrido;
    }

    public int getNumPasos() {
        return numPasos;
    }

    public void setNumPasos(int numPasos) {
        this.numPasos = numPasos;
    }

    public int getTiempoTranscurrido() {
        return tiempoTranscurrido;
    }

    public void setTiempoTranscurrido(int tiempoTranscurrido) {
        this.tiempoTranscurrido = tiempoTranscurrido;
    }
}
