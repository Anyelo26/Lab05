package com.example.rep_music.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.rep_music.R;

public class WindowLoadView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}